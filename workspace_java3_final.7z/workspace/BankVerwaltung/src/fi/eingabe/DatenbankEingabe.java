package fi.eingabe;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import fi.jdbc.DBZugriff;
import fi.klassen.Buchung;
import fi.klassen.DarlehensKonto;
import fi.klassen.GiroKonto;
import fi.klassen.KontoStamm;
import fi.klassen.SparKonto;
import fi.klassen.Ueberweisung;
import fi.schnittstellen.IEingabe;

public class DatenbankEingabe implements IEingabe {

	@Override
	public HashMap<Integer, KontoStamm> konten() {
		DBZugriff dbz = new DBZugriff();
		if (dbz.connectionAufbauen() == true) {
			// System.out.println("Connection Ok");
		} else {
			System.out.println("Connection nicht ok");
		}
		
		// Hashmap Erstellen in dem die eingelesenen Konten gespeichert werden
		HashMap<Integer, KontoStamm> konten = new HashMap<Integer, KontoStamm>();
		ResultSet rs;
		String sql;
		
		try {
			// Girokonten in Hashmap
			sql = 	"SELECT k.kontonummer, k.kontoinhaber, k.datum, gk.dispo, gk.sollzins " +
					"FROM girokonto gk, kontostamm k " + 
					"WHERE k.kontonummer = gk.kontonummer";
			rs = dbz.lesen(sql);
			
			while (rs.next()) {
				GiroKonto k = new GiroKonto();
				k.setKontoNummer(Integer.parseInt(rs.getString("kontonummer")));
				k.setKontoInhaber(rs.getString("kontoinhaber"));
				k.setDatum(rs.getString("datum"));
				k.setDispo(Double.parseDouble(rs.getString("dispo")));
				k.setSollZins(Double.parseDouble(rs.getString("sollzins")));
				konten.put(k.getKontoNummer(), k);
			}
			
			// Sparkonten in Hashmap
			sql = 	"SELECT k.kontonummer, k.kontoinhaber, k.datum, sk.habenzins, sk.kuendbetrag, sk.kuenddatum " +
					"FROM sparkonto sk, kontostamm k " + 
					"WHERE k.kontonummer = sk.kontonummer";
			rs = dbz.lesen(sql);
			
			while (rs.next()) {
				SparKonto k = new SparKonto();
				k.setKontoNummer(Integer.parseInt(rs.getString("kontonummer")));
				k.setKontoInhaber(rs.getString("kontoinhaber"));
				k.setDatum(rs.getString("datum"));
				k.setHabenZins(Double.parseDouble(rs.getString("habenzins")));
				k.setKuendBetrag(Double.parseDouble(rs.getString("kuendbetrag")));
				k.setKuendDatum(rs.getString("kuenddatum"));
				konten.put(k.getKontoNummer(), k);
			}
			
			// Darlehenskonten in Hashmap
			sql = "SELECT k.kontonummer, k.kontoinhaber, k.datum, dk.rate "+
					"FROM darlehenskonto dk, kontostamm k "+
					"WHERE k.kontonummer = dk.kontonummer";
			rs = dbz.lesen(sql);
			
			while(rs.next()) {
				DarlehensKonto k = new DarlehensKonto();
				k.setKontoNummer(Integer.parseInt(rs.getString("kontonummer")));
				k.setKontoInhaber(rs.getString("kontoinhaber"));
				k.setDatum(rs.getString("datum"));
				k.setRate(rs.getDouble("rate"));
				konten.put(k.getKontoNummer(), k);
			}
			return konten;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}

	@Override
	public ArrayList<Buchung> buchungen() {
		DBZugriff dbz = new DBZugriff();
		if (dbz.connectionAufbauen() == true) {
			// System.out.println("Connection Ok");
		} else {
			System.out.println("Connection nicht ok");
		}
		
		// Hashmap Erstellen in dem die eingelesenen Konten gespeichert werden
		ArrayList<Buchung> buchungen = new ArrayList<Buchung>();
		ResultSet rs;
		String sql;
		sql = "SELECT kontonummer, betrag, datum FROM buchung";
		rs = dbz.lesen(sql);
		try {
			while (rs.next()) {
				Buchung b = new Buchung();
				b.setKontoNummer(rs.getInt("kontonummer"));
				b.setBetrag(rs.getDouble("betrag"));
				b.setDatum("2016.10.10");
				buchungen.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return buchungen;
	}

	@Override
	public ArrayList<Ueberweisung> ueberweisungen(
			HashMap<Integer, KontoStamm> kontenMap) {
		// TODO Auto-generated method stub
		return null;
	}

}
