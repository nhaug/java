package fi.eingabe;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import fi.klassen.Buchung;
import fi.klassen.DarlehensKonto;
import fi.klassen.GiroKonto;
import fi.klassen.KontoStamm;
import fi.klassen.SparKonto;
import fi.klassen.Ueberweisung;
import fi.schnittstellen.IEingabe;

// Da wir hier mit dem Interface IEingabe arbeiten, muessen wir nun die Funktionalitaet der Interfaces beschreiben
public class DateiEingabe implements IEingabe {
	// Alle Variablen und Methoden sind standardmaessig bei Interfaces public
	private String bankDaten = "./files/Bankdaten2.txt";
	
	@Override
	public HashMap<Integer, KontoStamm> konten() {
		HashMap<Integer, KontoStamm> kontenMap = new HashMap<Integer, KontoStamm>();
		
		// Bei der Arbeit mit Dateien muss immer mit try - catch gearbeitet werden
		// Exceptions:
		// - FileNotFound 	: Wenn die Datei nicht vorhanden, ist (spezifisch auf dieses Problem)
		// - IOException 	: Wenn das Einlesen der Datei nicht funktioniert. Unsepzifisch... Exception faengt alles ab, was mit IO zu tun hat
		try {
			// Der BufferReader erwartet die Datei im Hauptspeicher
			// Um die Datei von der Festplatte in den Hauptspeicher zu lesen brauchen wir einen FileReader
			BufferedReader datei = new BufferedReader(new FileReader(bankDaten));
			String eingabe = null; 		// Hier werden die "Eingaben" aus der Datei gespeichert 
			
			// Nun die Datei Zeilenweise einlesen
			while ( ( eingabe = datei.readLine()) != null) {
				//System.out.println(eingabe);
				String[] teile = eingabe.split(";");
				
				int kontoNr=0;
				double dispo=0.0;
				double zinsSatz=0.0;
				String inhaber=null;
				double kuendBetrag=0.0;
				String kuendDatum=null;
				double rate=0.0;
				String datum = "10.10.2016";
				
				switch (teile[0]) {
				case "NeuesGiroKonto": 
					// Variablen fuer neues Girokonto belegen:
					kontoNr = Integer.parseInt(teile[1]);
					inhaber = teile[2];
					dispo = Double.parseDouble(teile[3]);
					zinsSatz = Double.parseDouble(teile[4]);
					
					// Neues Girokonto erstellen:
					GiroKonto giro = new GiroKonto();
					giro.setKontoNummer(kontoNr);
					giro.setKontoInhaber(inhaber);
					giro.setDispo(dispo);
					giro.setSollZins(zinsSatz);
					giro.setDatum(datum);
					
					// Objekt zur HashMap hinzufuegen
					kontenMap.put(giro.getKontoNummer(),giro);
					
					break;
					
				case "NeuesSparkonto": 
					// Variablen fuer Sparkonto belegen:
					kontoNr = Integer.parseInt(teile[1]);
					inhaber = teile[2];
					kuendBetrag = Double.parseDouble(teile[3]);
					kuendDatum = teile[4];
					zinsSatz = Double.parseDouble(teile[5]);
										
					// Neues SparKonto
					SparKonto spar = new SparKonto();
					spar.setKontoNummer(kontoNr);
					spar.setKontoInhaber(inhaber);
					spar.setHabenZins(zinsSatz);
					spar.setKuendBetrag(kuendBetrag);
					spar.setKuendDatum(kuendDatum);
					spar.setDatum(datum);
					
					// Objekt zur HashMap hinzufuegen
					kontenMap.put(spar.getKontoNummer(),spar);
					
					break;
					
				case "NeuesDarlehenskonto":
					// Variablen fuer Sparkonto belegen:
					kontoNr = Integer.parseInt(teile[1]);
					inhaber = teile[2];
					rate = Double.parseDouble(teile[3]);
					
					DarlehensKonto darlehn = new DarlehensKonto();
					darlehn.setKontoNummer(kontoNr);
					darlehn.setKontoInhaber(inhaber);
					darlehn.setRate(rate);
					darlehn.setDatum(datum);
					
					// Objekt zur HashMap hinzufuegen
					kontenMap.put(darlehn.getKontoNummer(),darlehn);
					break;
					
				}
				
			}
			datei.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			// Hier kann dann noch ein Hinweis fuer den Benutzer erscheinen und SSicherheitsrueckgabe, ob er eine 
			// andere Datei nutzen moechte
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return kontenMap;
	}

	@Override
	public ArrayList<Buchung> buchungen() {
		ArrayList<Buchung> buchungen = new ArrayList<Buchung>();
		
		// Bei der Arbeit mit Dateien muss immer mit try - catch gearbeitet werden
		// Exceptions:
		// - FileNotFound 	: Wenn die Datei nicht vorhanden, ist (spezifisch auf dieses Problem)
		// - IOException 	: Wenn das Einlesen der Datei nicht funktioniert. Unsepzifisch... Exception faengt alles ab, was mit IO zu tun hat
		try {
			// Der BufferReader erwartet die Datei im Hauptspeicher
			// Um die Datei von der Festplatte in den Hauptspeicher zu lesen brauchen wir einen FileReader
			BufferedReader datei = new BufferedReader(new FileReader(bankDaten));
			String eingabe = null; 		// Hier werden die "Eingaben" aus der Datei gespeichert 
			
			// Nun die Datei Zeilenweise einlesen
			while ( ( eingabe = datei.readLine()) != null) {
				//System.out.println(eingabe);
				String[] teile = eingabe.split(";");
				
				int kontoNr=0;
				double betrag=0.0;
				//System.out.println(eingabe);
				
				switch (teile[0]) {
				case "buchung":
					//System.out.println(eingabe);
					kontoNr = Integer.parseInt(teile[1]);
					betrag = Double.parseDouble(teile[2]);
					
					Buchung b = new Buchung();
					b.setDatum("10.10.2016");
					b.setKontoNummer(kontoNr);
					b.setBetrag(betrag);
					buchungen.add(b);
					break;
					
				}
				
			}
			datei.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			// Hier kann dann noch ein Hinweis fuer den Benutzer erscheinen und SSicherheitsrueckgabe, ob er eine 
			// andere Datei nutzen moechte
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return buchungen;
	}

	@Override
	public ArrayList<Ueberweisung> ueberweisungen(HashMap<Integer, KontoStamm> kontenMap) {
		ArrayList<Ueberweisung> ueberweisungen = new ArrayList<Ueberweisung>();
		// TODO Auto-generated method stub
		// Der BufferReader erwartet die Datei im Hauptspeicher
		// Um die Datei von der Festplatte in den Hauptspeicher zu lesen brauchen wir einen FileReader
		BufferedReader datei;
		try {
			datei = new BufferedReader(new FileReader(bankDaten));
			String eingabe = null; 		// Hier werden die "Eingaben" aus der Datei gespeichert 
			
			// Nun die Datei Zeilenweise einlesen
			while ( ( eingabe = datei.readLine()) != null) {
				//System.out.println(eingabe);
				String[] teile = eingabe.split(";");

				if (teile[0].equals("ueberweisung")) {
					KontoStamm absenderKonto = kontenMap.get(Integer.parseInt(teile[1]));
					String empfaengerBLZ = teile[2];
					String empfaengerKonto = teile[3];
					String empfaengerName = teile[4];
					Double betrag = Double.parseDouble(teile[5]);
					
					Ueberweisung u = new Ueberweisung();
					u.setAbsenderKto(absenderKonto);
					u.setEmpfaengerBLZ(empfaengerBLZ);
					u.setEmpfaengerKonto(empfaengerKonto);
					u.setEmpfaengerName(empfaengerName);
					u.setBetrag(betrag);
					ueberweisungen.add(u);
				}
				
			
			}
			datei.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ueberweisungen;
	}
	
}
