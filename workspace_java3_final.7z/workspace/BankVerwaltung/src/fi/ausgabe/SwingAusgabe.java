package fi.ausgabe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultListSelectionModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import fi.klassen.Buchung;
import fi.klassen.KontoStamm;
import fi.klassen.Ueberweisung;
import fi.schnittstellen.IAusgabe;

public class SwingAusgabe extends JFrame implements IAusgabe {
	private static final long serialVersionUID = 1L;
	
	// panel = Bedienungsfeld	
	private JPanel jContentPane = null;				// Pane Gesamt
	private JPanel jKonten = null;					// Pane Konten (West)
	private JPanel jKontoInfoPane = null;				// Pane KontoInfo (Center)
	private JPanel jBuchungPane = null;				// Pane Buchungen (Osten)
	private JPanel jColumnPane = null;				// Pane in dem die Feldnamen stehen
	private JTextField jKontoNummer = null;			// TextFeld fuer die Eingabe von Nachname
	private JTextField jKontoArt;
	private JTextField jKontoInhaber = null;		// TextFeld fuer die eingabe von Vorname
	private JTextField jSaldo = null;				// TextFeld fuer die eingabe von Vorname
	private JTextArea jBuchung = null;				// TextFeld fuer die eingabe von Vorname
	
	//private JButton btEnde = null;				// Button einbauen, auf den geklickt werden kann und das Fenster schlie�t
	private Color defaultColorBG = Color.WHITE;		// Default Color f�r Background
	private JList<String> lbKonten = null;			// Listbox mit den Konten
	private HashMap<Integer, KontoStamm> kontenMap = null;
	private int selectedKontoNr;
	
	public void setSelectedKontoNr (int selectedKontoNr) {
		this.selectedKontoNr = selectedKontoNr;
	}
	
	public int getSelectedKontoNr() {
		return selectedKontoNr;
	}

	@Override
	public void konten(HashMap<Integer, KontoStamm> kontenMap) {
		// Size width , high
		this.setKontenMap(kontenMap);
		this.setSize(600, 400);				// Setze groesse des Frames mit pixel-Angaben
		this.setTitle("Kontenanzeige");		// Setze Titel auf Hello World
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	// Wenn bei dem Frame auf "Close" geklickt wird, wird der Java-Prozess beendet und vom Garbage Collector entfernt.
		this.setContentPane(getJKontoAnzeige());		// Aufbauen des Standard Panels
		this.setResizable(false);				// Benutzer kann das Fenster nicht skalieren. Dadurch sieht die Anwendung immer gut aus.
		this.setVisible(true);
		
	}

	private void setKontenMap(HashMap<Integer, KontoStamm> kontenMap) {
		// TODO Auto-generated method stub
		this.kontenMap = kontenMap;
	}

	@Override
	public void fehler(KontoStamm k, Buchung b, String fehlerText) {
		// TODO Auto-generated method stub
		
	}
	
	// Funktion, die Standard-Panel aufbaut
	private JPanel getJKontoAnzeige() {
		jContentPane = new JPanel();
		
		// Layouts: 
		//	Standard = FlowLayout (	Wenn ich kein  Layout festlege, wird das FlowLayout genutzt )
		//	meistverbreitete = BorderLayout
		jContentPane.setLayout(new BorderLayout(10,10));
		//jContentPane.setLayout(null);
		jContentPane.setBackground(defaultColorBG);
		
		// Im BorderLayout die einzelnen Seiten als Button macht
		//jContentPane.add(getJColumnPane(),BorderLayout.NORTH);
		jContentPane.add(getJKonten(),BorderLayout.WEST);
		jContentPane.add(getJKontoInfoPane(),BorderLayout.CENTER);
		jContentPane.add(getJBuchungenPane(),BorderLayout.EAST);
		//jContentPane.add(getJKonten());
		//jContentPane.add(getJKontoInfoPane());
		//jContentPane.add(getJBuchungenPane());

		return jContentPane;
	}



	private JPanel getJKonten() {
		// Definition was im Westen geschehen soll
		// Hier soll eine Liste angezeigt werden
		jKonten = new JPanel();
		jKonten.setBounds(5, 5, 150, 500);
		jKonten.add(new JLabel("Vorhandene Konten"));
		lbKonten = new JList<String>();
		Vector<String> konten = new Vector<String>();
		
		for ( KontoStamm k : kontenMap.values()) {
			konten.add(k.getKontoNummer()+"-"+k.getClass().getSimpleName());
		}
		
		lbKonten.setListData(konten);
		lbKonten.setSelectionMode(DefaultListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		lbKonten.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				// TODO Auto-generated method stub
				String[] select = lbKonten.getSelectedValue().split("-");
				setSelectedKontoNr(Integer.parseInt(select[0]));
								
				KontoStamm k = kontenMap.get(selectedKontoNr);
				
				jKontoNummer.setText(""+k.getKontoNummer());
				jKontoArt.setText(""+k.getClass().getSimpleName());
				jKontoInhaber.setText(k.getKontoInhaber());
				jSaldo.setText(""+k.getSaldo());
				String buchungString = "";
				for (Buchung b : k.getBuchungen()) {
					buchungString += b.getDatum() + " " + b.getBetrag() + "\n";
				}
				jBuchung.setText(buchungString);
				
			}
		});

		jKonten.add(lbKonten); 
		
		return jKonten;
	}
	
	
	private JPanel getJKontoInfoPane() {
		// Frame f�r KontoInfo aufbauen
		jKontoInfoPane = new JPanel();
		//jKontoInfoPane.setLayout(null);
		jKontoInfoPane.setLayout(new GridLayout(9,1));
		jKontoInfoPane.setBounds(110, 5, 300, 500);
		
		// Kontonummer anzeigen
		jKontoInfoPane.add(new JLabel("Kto-Nr."));
		jKontoNummer = new JTextField();
		jKontoNummer.setEditable(false);
		jKontoInfoPane.add(jKontoNummer);
		
		// Kontoart anzeigen
		jKontoInfoPane.add(new JLabel("Kontoart"));
		jKontoArt = new JTextField();
		jKontoArt.setEditable(false);
		jKontoInfoPane.add(jKontoArt);
		
		// KontoInhaber anzeigen
		jKontoInfoPane.add(new JLabel("Inhaber"));
		jKontoInhaber = new JTextField();
		jKontoInhaber.setEditable(false);
		jKontoInfoPane.add(jKontoInhaber);
		
		// Saldo anzeigen
		jKontoInfoPane.add(new JLabel("Saldo"));
		jSaldo = new JTextField();
		jSaldo.setEditable(false);
		jKontoInfoPane.add(jSaldo);
		
		//FocusListener focusImpl = new FocusListenerImplement();
		
		return jKontoInfoPane;
	}
		
	private Component getJBuchungenPane() {
		// TODO Auto-generated method stub
		jBuchungPane = new JPanel();
		jBuchungPane.setLayout(new GridLayout(1, 1));
		
		jBuchung = new JTextArea();
		jBuchung.setText("                                     ");
		jBuchung.setEditable(false);
		jBuchungPane.add(jBuchung);
		// Hier nun die Buchungen zu dem ausgeaehlten Konto anzeigen
		return jBuchungPane;
	}

	@Override
	public void ueberweisungen(ArrayList<Ueberweisung> ueberweisungen) {
		// TODO Auto-generated method stub
		
	}



}
