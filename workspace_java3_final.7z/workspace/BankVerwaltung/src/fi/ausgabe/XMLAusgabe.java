package fi.ausgabe;

import java.util.ArrayList;
import java.util.HashMap;

import fi.klassen.Buchung;
import fi.klassen.KontoStamm;
import fi.klassen.Ueberweisung;
import fi.klassen.XMLDokument;
import fi.schnittstellen.IAusgabe;

public class XMLAusgabe implements IAusgabe {

	@Override
	public void konten(HashMap<Integer, KontoStamm> kontenMap) {
		// TODO: Ausgabe in XML und nicht auf Konsole
		IAusgabe ausgabe = new konsolenAusgabe();
		ausgabe.konten(kontenMap);
	}

	@Override
	public void fehler(KontoStamm k, Buchung b, String fehlerText) {
		// TODO: Ausgabe in XML und nicht auf Konsole
		IAusgabe ausgabe = new konsolenAusgabe();
		ausgabe.fehler(k, b, fehlerText);
	}

	@Override
	public void ueberweisungen(ArrayList<Ueberweisung> ueberweisungen) {
		// TODO Auto-generated method stub
		// String datei = "./files/Bankueberweisung.xml";
		String datei = "C:\\Users\\BLS\\workspace\\BankVerwaltung\\files\\Ueberweisung.xml";
		XMLDokument doc = new XMLDokument(datei);
		doc.dokumentErstellen();
		doc.XMLDatenErstellen(ueberweisungen);
		doc.dokumentSchreiben();
	}



}
