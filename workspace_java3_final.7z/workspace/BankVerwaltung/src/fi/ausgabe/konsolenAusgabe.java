package fi.ausgabe;

import java.util.ArrayList;
import java.util.HashMap;

import fi.klassen.Buchung;
import fi.klassen.KontoStamm;
import fi.klassen.Ueberweisung;
import fi.schnittstellen.IAusgabe;

public class konsolenAusgabe implements IAusgabe {

	@Override
	public void konten(HashMap<Integer, KontoStamm> kontenMap) {
		// TODO Auto-generated method stub
		
		for (KontoStamm k : kontenMap.values()) {
			String ausgabe = null;
			ausgabe = k.getInfo();
			System.out.println(ausgabe);
		}
	}

	@Override
	public void fehler(KontoStamm k, Buchung b, String fehlerText) {
		// TODO Auto-generated method stub
		String s;
		s = "------------------------";
		s += "\n" + k.aufbereitungFehler(k, b, fehlerText);
		s += "\n-----------------------";
		System.out.println(s);
	}

	@Override
	public void ueberweisungen(ArrayList<Ueberweisung> ueberweisungen) {
		// TODO Auto-generated method stub
		
	}




}
