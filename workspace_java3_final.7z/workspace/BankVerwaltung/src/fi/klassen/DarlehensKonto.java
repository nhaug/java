package fi.klassen;

public class DarlehensKonto extends KontoStamm {
	private double rate;
	
	public double getRate() {
		 // 
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String buchungsPruefung(Buchung b) {
		// TODO Auto-generated method stub
		if (this.rate == b.getBetrag()) {
			return null;
		} else {
			return "----> Buchungsbetrag muss der Rate entsprechen";
		}
	}

	@Override
	public String getSpezifischeInfo() {
		String s;
		s = "\nRate   : " + this.getRate();
		return s;
	}
}
