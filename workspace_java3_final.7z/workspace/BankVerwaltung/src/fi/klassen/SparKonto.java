package fi.klassen;

public class SparKonto extends KontoStamm {
	// Instanzvariablen
	private double habenZins;
	private double kuendBetrag;
	private String kuendDatum;
	
	// Getter Setter
	public double getHabenZins() {
		return habenZins;
	}
	public void setHabenZins(double habenZins) {
		this.habenZins = habenZins;
	}
	public double getKuendBetrag() {
		return kuendBetrag;
	}
	public void setKuendBetrag(double kuendBetrag) {
		this.kuendBetrag = kuendBetrag;
	}
	public String getKuendDatum() {
		return kuendDatum;
	}
	public void setKuendDatum(String kuendDatum) {
		this.kuendDatum = kuendDatum;
	}
	
	@Override
	public String buchungsPruefung(Buchung b) {
		if ( (this.getSaldo()+b.getBetrag()) < 0) {
			return "----> Konto ist nicht gedeckt";
		} else {
			return null;
		}
	}
	
	@Override
	public String getSpezifischeInfo() {
		String s;
		s = "\nHabenzins   : " + this.getHabenZins();
		s+= "\nKuendBetrag : " + this.getKuendBetrag();
		s+= "\nKuendDatum  : " + this.getKuendDatum();
		return s;
	}
}
