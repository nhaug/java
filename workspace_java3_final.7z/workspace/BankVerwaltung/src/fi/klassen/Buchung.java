package fi.klassen;

public class Buchung {
	/*
	 * Beschreibung: 	Hier werden die Buchungen bearbeitet.
	 * 					Eine Buchung ist dabei immer mit einem Konto assoziert.
	 * 
	 */
	// Instanzvariable
	private int kontoNummer;
	private double betrag;
	private String datum;
	
	
	public void setDatum(String datum) {
		this.datum = datum;
	}
	// Getter Setter
	public int getKontoNummer() {
		return kontoNummer;
	}
	public void setKontoNummer(int kontoNummer) {
		this.kontoNummer = kontoNummer;
	}
	public double getBetrag() {
		return betrag;
	}
	public void setBetrag(double betrag) {
		this.betrag = betrag;
	}
	public String getDatum() {
		return datum;
	}
}
