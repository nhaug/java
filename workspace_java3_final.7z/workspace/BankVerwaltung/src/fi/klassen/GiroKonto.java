package fi.klassen;

public class GiroKonto extends KontoStamm {
	// Instanzvariablen:
	private double dispo;
	private double sollZins;
	
	// Getter Setter
	public double getDispo() {
		return dispo;
	}
	public void setDispo(double dispo) {
		this.dispo = dispo;
	}
	public double getSollZins() {
		return sollZins;
	}
	public void setSollZins(double sollZins) {
		this.sollZins = sollZins;
	}
	
	@Override
	public String buchungsPruefung(Buchung b) {
		// Saldo darf nach der Buchung nicht kleiner als Dispo sein
		// Bei if-Abfrage, muss der saldo mit -1 multipliziert werden, da dieser ja im negativen geprueft werden muss!
		double saldoNachBuchung = this.getSaldo() + b.getBetrag(); 
		if (saldoNachBuchung < (this.getDispo() * -1)) {
			return "----> Dispo Limit ist ueberschritten";
		} else {
			return null;
		}
	}
	
	@Override
	public String getSpezifischeInfo() {
		String s;
		s = "\nDispo  : " + this.getDispo();
		s+= "\nSollzins :" + this.getSollZins();
		return s;
	}

}
