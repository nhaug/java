package fi.klassen;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLDokument {
	private String datei = null;
	private Document xmlDoc = null;
	private Element root = null;
	
	public XMLDokument(String datei) {
		super();
		System.out.println("neues xmlDokument");
		this.setDatei(datei);
	}
	
	// Getter Setter
	public Document getXmlDoc() {
		return xmlDoc;
	}

	public void setXmlDoc(Document xmlDoc) {
		this.xmlDoc = xmlDoc;
	}

	public Element getRoot() {
		return root;
	}

	public void setRoot(Element root) {
		this.root = root;
	}

	private void setDatei(String datei) {
		// TODO Auto-generated method stub
		datei = this.datei;
	}
	
	public String getDatei() {
		return datei;
	}
	
	
	public void dokumentErstellen() {
		System.out.println("Dokument Erstellen");
		try {
			// Objekt der Hauptklasse
			// wird erstellt �ber Single-Ton Pattern
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			
			// Builder Aufbau der Grundstruktur fuer XML
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			// Document fuer die Aufnahme aller Knoten & Attribute
			Document xmlDoc = builder.newDocument();
			this.setXmlDoc(xmlDoc);

		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public void XMLDatenErstellen(ArrayList<Ueberweisung> ueberweisungen) {
		// Erzeugen aller Elemente, die in xmlDoc gespeichert werden sollen
		// Zuerst das root-Element erzeugen, welches das oberste Element in der Hierarchie ist
		Document doc = this.getXmlDoc();
		Element root = doc.createElement("Ueberweisungen");
		
		// Aufbau der XML-Hierarchie und Zuordnung von Elementen
		// Dabei wird von root -> unterster Ebene vorgegangen werden
		// TODO: Evtl lohnt es sich auch das xmlDoc andersherum aufzubauen
		doc.appendChild(root);
		this.setXmlDoc(doc);
	}
	
	
	
	public void dokumentSchreiben() {

		try {
			// Festlegen der Datei in dem das xmlDoc abgelegt werden soll
			File f = new File(this.getDatei());
			
			// TODO: Herausfinden, wie mit den Ordnern aus Eclipse gearbeitet werden kann 
			// File f = new File(xmlF)
			
			// Stream der Daten in Datei bef�rdern
			Result result = new StreamResult(f);
			
			// Source f�r die Entgegenname unseres Dokuments
			// nach den Vorghaben des DOM-Modelles
			// Hier sind die Daten enthalten
			Source source = new DOMSource(this.getXmlDoc());
			
			// Umwandeln und Schreiben des Dokuments in die Datei
			Transformer transformer;
			transformer = TransformerFactory.newInstance().newTransformer();
			
			// Methode die den XML Aufbau und den Stram fuer das Schreiben durchfuehrt
			transformer.transform(source, result);
			
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	public void knotenLesen(Node n) {
		// Auswertung der Knoten
		// Knoten kann 2 Status haben:
		// 1. Nur Attribute
		// 2. Hat weitere UnterKnoten
		
		// Knoten, mit UnterKnoten
		if ( n.getNodeType() == Node.ELEMENT_NODE) {
			System.out.println("Knoten " + n.getNodeName());
			
			// Attribute ausgeben falls vorhanden
			for (int i = 0; i < n.getAttributes().getLength(); i++) {
				// Ausgabe AttributName + AttributValue
				System.out.println("Attribut " + n.getAttributes().item(i));
			}
		}
		
		if (n.getNodeType() == Node.TEXT_NODE) {
			if (n.getNodeValue().trim().length() != 0) {
				String s = n.getNodeValue().trim();
				System.out.println("node Value " + s);
			}
			
		}
		
		// Jetzt kommt die Rekurssion
		NodeList children = n.getChildNodes();
		if (children.getLength() > 0 ) {
			for ( int i=0; i < children.getLength(); i++) {
				knotenLesen(children.item(i));
			}
		}
	}
}
