package fi.klassen;

public class Ueberweisung {
	private KontoStamm absenderKto;
	private String empfaengerBLZ;
	private String empfaengerKonto;
	private String empfaengerName;
	// TODO: Brauchen wir tatsaechlich den Betrag als lokale Variable? Koennen wir nicht den Betrag aus der Buchung nehmen?
	private Double betrag;
	
	public KontoStamm getAbsenderKto() {
		return absenderKto;
	}
	public void setAbsenderKto(KontoStamm absenderKto) {
		this.absenderKto = absenderKto;
	}
	public String getEmpfaengerBLZ() {
		return empfaengerBLZ;
	}
	public void setEmpfaengerBLZ(String empfaengerBLZ) {
		this.empfaengerBLZ = empfaengerBLZ;
	}
	public String getEmpfaengerKonto() {
		return empfaengerKonto;
	}
	public void setEmpfaengerKonto(String empfaengerKonto) {
		this.empfaengerKonto = empfaengerKonto;
	}
	public String getEmpfaengerName() {
		return empfaengerName;
	}
	public void setEmpfaengerName(String empfaengerName) {
		this.empfaengerName = empfaengerName;
	}
	public Double getBetrag() {
		return betrag;
	}
	public void setBetrag(Double betrag) {
		this.betrag = betrag;
	}
	
}
