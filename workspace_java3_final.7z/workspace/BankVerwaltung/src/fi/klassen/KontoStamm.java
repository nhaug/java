package fi.klassen;

import java.util.ArrayList;

public abstract class KontoStamm{
	// abstract : Es kann von dieser Klasse keine Instanz erstellt werden, sondern nur von den Subklassen
	// Diese Klasse ist die Basis-Klasse unseres Projektes
	
	// Instanzvariablen:
	// -----------------
	private String datum;
	private String kontoInhaber;
	private int kontoNummer;
	private double saldo;
	private ArrayList<Buchung> buchungen = new ArrayList<Buchung>();
	private ArrayList<Ueberweisung> ueberweisungen = new ArrayList<Ueberweisung>();

	// getter und setter: ( Generierung via : rechts-Klick > Source > generate getter-setter )
	// ----------------------
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public String getKontoInhaber() {
		return kontoInhaber;
	}
	public void setKontoInhaber(String kontoInhaber) {
		this.kontoInhaber = kontoInhaber;
	}
	public int getKontoNummer() {
		return kontoNummer;
	}
	public void setKontoNummer(int kontoNummer) {
		this.kontoNummer = kontoNummer;
	}
	public double getSaldo() {
		return saldo;
	}
	public ArrayList<Buchung> getBuchungen() {
		return buchungen;
	}
	public ArrayList<Ueberweisung> getUeberweisungen() {
		return ueberweisungen;
	}
	
	// Weitere Methoden
	// ----------------
	public String getInfo() {
		// String fuer Ausgabe zusammenbauen, damit dieser bei jeder Ausgabe immer gleich aussieht
		String s = "---";
		s+= "\nKontoNr : " + this.getKontoNummer();
		s+= "\nArt     : " + this.getClass().getSimpleName();
		s+= "\nInhaber : " + this.getKontoInhaber();
		s+= "\nSaldo   : " + this.getSaldo();
		s+= this.getSpezifischeInfo();
		s+= "\n---Zugehoerige Buchungen ---";
		for (Buchung b : this.getBuchungen()) {
			s+= "\n" +b.getDatum() +" "+ b.getBetrag();
		}
		s+= "\n---Zugehoerige Ueberweisungen ---";
		for (Ueberweisung u : this.getUeberweisungen())
			s+= "\n"+u.getBetrag()+"� an "+u.getEmpfaengerName();
		s+="\n";
		
		return s;
	}
	
	public abstract String getSpezifischeInfo ();
	
	public void verarbeiteBuchung (Buchung b) {
		this.saldo += b.getBetrag();
		this.buchungen.add(b);
	}
	
	public void verarbeiteUeberweisung (Ueberweisung u ) {
		this.saldo += u.getBetrag();
		this.ueberweisungen.add(u);
	}
	
	// Abstrakte Methoden werden genutzt, um in den Unterklassen eine Implementierung zu erzwingen
	// Abstrakte Methoden k�nnen nur in abstrakten Klassen deklariert werden.
	// Diese Methode soll die Pruefung je nach KontoArt pruefen. Die Pruefungen unterscheiden sich bei den Kontotypen.
	public abstract String buchungsPruefung(Buchung b);
	
	public String aufbereitungFehler(KontoStamm k, Buchung b, String text) {
		String s;
		s = "Buchung in Hoehe von ";
		s += b.getBetrag();
		s += " fuer das Konto ";
		s += k.getKontoNummer();
		s += " < " + this.getClass().getSimpleName() +" > ";
		s += "kann nicht durchgefuehrt werden";
		s += "\n" + text;
		return s;
	}

	/*	
	public String prepareInsertQueryKonten() {
		String sql;
		sql = "INSERT INTO kontostamm (kontonummer,kontoinhaber,saldo) VALUES ("+
				"'"+this.getKontoNummer()+"'"+
				",'"+this.getKontoInhaber()+"'"+
				",'"+this.getSaldo()+"'"+
				")";
		return sql;
	}*/

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	
	
}
