package fi.applikationen;

import java.util.ArrayList;
import java.util.HashMap;

import fi.ausgabe.SwingAusgabe;
import fi.ausgabe.XMLAusgabe;
import fi.ausgabe.konsolenAusgabe;
import fi.eingabe.DateiEingabe;
import fi.eingabe.DatenbankEingabe;
import fi.jdbc.DBZugriff;
import fi.klassen.Buchung;
import fi.klassen.KontoStamm;
import fi.klassen.Ueberweisung;
import fi.schnittstellen.IAusgabe;
import fi.schnittstellen.IEingabe;

public class AppIO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Hier Interface IEingabe nutzen, damit spaeter variable zwischen den Input genutzt werden kann 
		//IEingabe eingabe = new DatenbankEingabe();
		IEingabe eingabe = new DateiEingabe();
		IAusgabe ausgabe = new XMLAusgabe();
		//IAusgabe ausgabe = new SwingAusgabe();
		
		// Konten in HashMap einlesen
		HashMap<Integer, KontoStamm> konten = eingabe.konten();
		
		// Konten in DB speichern:
		DBZugriff dbz = new DBZugriff();
		dbz.connectionAufbauen();
		
		ArrayList<Buchung> buchungen = eingabe.buchungen();
		for (Buchung b : buchungen) {
			KontoStamm k = konten.get(b.getKontoNummer());
			String ergebnisPruefung = k.buchungsPruefung(b);
			if (ergebnisPruefung == null) {
				k.verarbeiteBuchung(b);
			} else {
				ausgabe.fehler(k, b, ergebnisPruefung);;
			}
		}
		
		ArrayList<Ueberweisung> ueberweisungen = eingabe.ueberweisungen(konten);
		for (Ueberweisung u : ueberweisungen) {
			KontoStamm k = u.getAbsenderKto();
			k.verarbeiteUeberweisung(u);
		}
		
		ausgabe.konten(konten);
		ausgabe.ueberweisungen(ueberweisungen);
	}

}
