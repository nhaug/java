package fi.applikationen;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import fi.ausgabe.konsolenAusgabe;
import fi.eingabe.DateiEingabe;
import fi.jdbc.DBZugriff;
import fi.klassen.Buchung;
import fi.klassen.DarlehensKonto;
import fi.klassen.GiroKonto;
import fi.klassen.KontoStamm;
import fi.klassen.SparKonto;
import fi.schnittstellen.IAusgabe;
import fi.schnittstellen.IEingabe;

public class AppImportDaten {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		DBZugriff dbz = new DBZugriff();
		dbz.connectionAufbauen();
		
		dbz.update("Delete from Buchung");
		dbz.update("Delete from GiroKonto");
		dbz.update("Delete from SparKonto");
		dbz.update("Delete from Darlehenskonto");
		dbz.update("Delete from Kontostamm");
		
		IEingabe eingabe = new DateiEingabe();
		HashMap<Integer, KontoStamm> konten = eingabe.konten();
		ArrayList<Buchung> buchungen = eingabe.buchungen();
		
		// Connection liefern
		Connection conn = dbz.getConn();
		
		
		IAusgabe ausgabe = new konsolenAusgabe();
		
		
		try {
			for( KontoStamm k : konten.values()) {
				System.out.println("Kontostamm anlegen");
				
				PreparedStatement prep = conn.prepareStatement(
						"Insert into kontostamm values (?,?,?,?)");
				prep.setInt(1, k.getKontoNummer());
				prep.setString(2, k.getKontoInhaber());
				prep.setString(3, "2016.10.10");
				prep.setDouble(4, 0);
				prep.executeUpdate();
				
				if (k.getClass().getSimpleName().toLowerCase().equals("girokonto")) {
					GiroKonto gk = (GiroKonto)k;
					System.out.println("GiroKonto anlegen");
					prep = conn.prepareStatement(
							"Insert into girokonto (kontonummer, dispo, sollzins) values (?,?,?)");
					prep.setInt(1, gk.getKontoNummer());
					prep.setDouble(2, gk.getDispo());
					prep.setDouble(3, gk.getSollZins());
					prep.executeUpdate();
					
				} if (k.getClass().getSimpleName().toLowerCase().equals("sparkonto")) {
					SparKonto sk = (SparKonto)k;
					System.out.println("SparKonto anlegen");
					prep = conn.prepareStatement(
							"Insert into sparkonto (kontonummer,habenzins,kuendbetrag,kuenddatum) values (?,?,?,?)");
					prep.setInt(1, sk.getKontoNummer());
					prep.setDouble(2, sk.getHabenZins());
					prep.setDouble(3, sk.getKuendBetrag());
					prep.setString(4, "2016.10.14");
					prep.executeUpdate();
					
				} if (k.getClass().getSimpleName().toLowerCase().equals("darlehenskonto")) {
					DarlehensKonto dk = (DarlehensKonto)k;
					System.out.println("Darlehenskonto anlegen");
					prep = conn.prepareStatement(
							"Insert into Darlehenskonto (kontonummer,rate) values (?,?)");
					prep.setInt(1, dk.getKontoNummer());
					prep.setDouble(2, dk.getRate());					
					prep.executeUpdate();
	
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Buchungen in DB speichern");
		for ( Buchung b : buchungen) {
			try {
				PreparedStatement prep = conn.prepareStatement(
						"Insert into buchung (kontonummer, betrag, datum) values (?,?,?)");
				
				prep.setInt(1, b.getKontoNummer());
				prep.setDouble(2,b.getBetrag());
				prep.setString(3,"2016.10.10");
				prep.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					
		}
		
		ausgabe.konten(konten);
	}

}
