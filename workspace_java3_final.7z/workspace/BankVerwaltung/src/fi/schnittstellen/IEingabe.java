package fi.schnittstellen;

import java.util.ArrayList;
import java.util.HashMap;

import fi.klassen.Buchung;
import fi.klassen.KontoStamm;
import fi.klassen.Ueberweisung;

public interface IEingabe {
	// Objekt f�r den Datentyp int ist Integer
	HashMap<Integer, KontoStamm> konten();
	ArrayList<Buchung> buchungen();
	ArrayList<Ueberweisung> ueberweisungen(HashMap<Integer, KontoStamm> kontenMap);
	
}
