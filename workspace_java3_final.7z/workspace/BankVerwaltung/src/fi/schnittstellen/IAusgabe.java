package fi.schnittstellen;

import java.util.ArrayList;
import java.util.HashMap;

import fi.klassen.Buchung;
import fi.klassen.KontoStamm;
import fi.klassen.Ueberweisung;

public interface IAusgabe {
	void konten(HashMap<Integer, KontoStamm> kontenMap);
	void fehler(KontoStamm k, Buchung b, String fehlerText);
	void ueberweisungen(ArrayList<Ueberweisung> ueberweisungen);
}
