package xml.app;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class AppXmlLesen {

	public static void main(String[] args) {

		
		// Builder Aufbau der Grundstruktur fuer XML
		try {
			// Dokument zur Verf�gung stellen (s. Lesen)
			// wird erstellt �ber Single-Ton Pattern
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			File f = new File("./xmlFiles/domxml2.xml");
			Document xmlDoc = builder.parse(f);
			
			// Da wir nicht wissen, wie tief der XML-Baum ist, nutzen wir eine Rekurssion
			// Rekurssion: Die Methode ruft sich selbst wieder auf
			// Wenn Element ein UnterElement hat, dann soll die Methode wieder aufgerufen werden
			// Wiederhole solange, bis wir auf der untersten Ebene angekommen sind
			
			Node root = xmlDoc.getDocumentElement();
			
			knotenLesen(root);
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Dokument auslesen

	}
	
	// Methode wird von der Main aufgerufen ... Keine Objekt-Methode!
	static void knotenLesen(Node n) {
		// Auswertung der Knoten
		// Knoten kann 2 Status haben:
		// 1. Nur Attribute
		// 2. Hat weitere UnterKnoten
		
		// Knoten, mit UnterKnoten
		if ( n.getNodeType() == Node.ELEMENT_NODE) {
			System.out.println("Knoten " + n.getNodeName());
			
			// Attribute ausgeben falls vorhanden
			for (int i = 0; i < n.getAttributes().getLength(); i++) {
				// Ausgabe AttributName + AttributValue
				System.out.println("Attribut " + n.getAttributes().item(i));
			}
		}
		
		if (n.getNodeType() == Node.TEXT_NODE) {
			if (n.getNodeValue().trim().length() != 0) {
				String s = n.getNodeValue().trim();
				System.out.println("node Value " + s);
			}
			
		}
		
		// Jetzt kommt die Rekurssion
		NodeList children = n.getChildNodes();
		if (children.getLength() > 0 ) {
			for ( int i=0; i < children.getLength(); i++) {
				knotenLesen(children.item(i));
			}
		}
	}

}
