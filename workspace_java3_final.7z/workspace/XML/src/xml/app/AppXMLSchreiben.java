package xml.app;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class AppXMLSchreiben {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// try-catch zum abfangen von Fehlern beim xmlBuilder
		try {
			// Objekt der Hauptklasse
			// wird erstellt �ber Single-Ton Pattern
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			
			// Builder Aufbau der Grundstruktur fuer XML
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			// Document fuer die Aufnahme aller Knoten & Attribute
			Document xmlDoc = builder.newDocument();
			
			// Erzeugen aller Elemente, die in xmlDoc gespeichert werden sollen
			// Zuerst das root-Element erzeugen, welches das oberste Element in der Hierarchie ist
			Element root = xmlDoc.createElement("root");
			Element unter1 = xmlDoc.createElement("unterKnoten");
			unter1.setAttribute("Beschreibung",  "Unter Knoten");
			unter1.setTextContent("Eintrag1");		// Attribut von unter1
			
			// Aufbau der XML-Hierarchie und Zuordnung von Elementen
			// Dabei wird von root -> unterster Ebene vorgegangen werden
			// TODO: Evtl lohnt es sich auch das xmlDoc andersherum aufzubauen
			xmlDoc.appendChild(root);
			
			// dem root-Element das unter1 zuordnen
			root.appendChild(unter1);
			
			// Festlegen der Datei in dem das xmlDoc abgelegt werden soll
			File f = new File("./xmlFiles/domxml2.xml");
			
			// TODO: Herausfinden, wie mit den Ordnern aus Eclipse gearbeitet werden kann 
			// File f = new File(xmlF)
			
			// Stream der Daten in Datei bef�rdern
			Result result = new StreamResult(f);
			
			// Source f�r die Entgegenname unseres Dokuments
			// nach den Vorghaben des DOM-Modelles
			// Hier sind die Daten enthalten
			Source source = new DOMSource(xmlDoc);
			
			// Umwandeln und Schreiben des Dokuments in die Datei
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			
			// Methode die den XML Aufbau und den Stram fuer das Schreiben durchfuehrt
			transformer.transform(source, result);
			
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
