package klassen;

import java.util.ArrayList;
import java.util.HashMap;


// Festlegen, dass die Klasse mit einem Datentyp aufgerufen werden muss
public class DemoGenerica<T> {
		
	public void wert (T val) {
		System.out.println(val);
	}
		
	public void zufall (T wert0, T wert1) {
		for ( int i=0; i<10; i++) {
			int anzuzeigenderWert = (int) (Math.random()*2);
			if (anzuzeigenderWert == 0) {
				System.out.println(wert0);
			} else {
				System.out.println(wert1);
			}
		}
	}
}
