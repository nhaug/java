package klassen;

import java.util.ArrayList;

public class BayrischeListe<T> {
	private ArrayList<T> liste = new ArrayList<T>();
	
	public void fuegmahinzu(T wert) {
		liste.add(wert);
	}
	public void gibaus() {
		for (T wert : liste) {
			System.out.println(wert);
		}
	}
}
