package Applikationen;

import klassen.BayrischeListe;
import klassen.DemoGenerica;

public class AppGenerica {
	public static void main(String[] args) {
		DemoGenerica<Integer> d = new DemoGenerica<Integer>();
		d.wert(1);
		d.zufall(123, 11);
		
		DemoGenerica<String> s = new DemoGenerica<String>();
		s.wert("Huber");
		s.zufall("hallo" , "World");
		
		BayrischeListe<String> arB = new BayrischeListe<String>();
		arB.fuegmahinzu("Bayrische");
		arB.fuegmahinzu("Liste");
		arB.gibaus();
	}
	
}
