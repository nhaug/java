package fi.jdbc;

public class AppInsert {
	public static void main(String[] args) {
		DBZugriff dbz = new DBZugriff();
		dbz.connectionAufbauen();
		
		String plz="41000";
		String ort="M�nster";
		String sql = "INSERT INTO plz (plz,ort) VALUES('"+plz+"','"+ort+"')";
		
		System.out.println("Hinzugefuegt wurden "+dbz.update(sql)+" S�tze");
	}
}
