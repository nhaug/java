package fi.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class AppMetaData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DBZugriff dbz = new DBZugriff();
		dbz.connectionAufbauen();
		
		Connection conn = dbz.getConn();
		String sql = "SELECT * FROM plz";
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			// ResultSet Meta liefert die Metadaten der entsprechenden Tabelle zur�ck
			ResultSetMetaData meta = rs.getMetaData();
			int anzahl = meta.getColumnCount();
			// System.out.println("Anzahl der Spalten " +anzahl);

			for ( int i = 1; i <= anzahl; i++ ) {
				System.out.println(i+". Spaltenbezeichner: " +meta.getColumnLabel(i));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
