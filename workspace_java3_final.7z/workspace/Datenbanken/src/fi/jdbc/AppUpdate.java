package fi.jdbc;

public class AppUpdate {

	public static void main(String[] args) {
		// Klasse soll zum Update von Datensaetzen genutzt werden
		
		DBZugriff dbz = new DBZugriff();
		dbz.connectionAufbauen();
		
		String sql = "UPDATE plz set plz = '41100' WHERE ort = 'M�nster'";
		System.out.println("Es wurden "+dbz.update(sql)+" Datensaetze aktualisiert");

	}

}
