package fi.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBZugriff {
	
	// Deklaration der Klassen fuer JDBC:
	private Connection conn = null;
	
	public Connection getConn() {
		return conn;
	}

	private Statement stmt = null;
	private ResultSet rs = null;
	
	public boolean connectionAufbauen() {
		
		try {
			// Bekanntgabe der Treiber-Klasse
			Class.forName("com.mysql.jdbc.Driver");
			
			// ConnectionString aufbauen .. Unterscheidet sich zwischen Herstellern
			String connectionString = 
					"jdbc:mysql:"+ 			// es handelt sich um mysql
					"//localhost:3306"+ 	// Host mit Port
					"/kurs3"+				// Datenbank
					"?user=root"+			// User
					"&password=mysql";		// Passwort
			
			conn = DriverManager.getConnection(connectionString);
			return true;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	public ResultSet lesen(String sql) {
		
		try {
			// Erstellen des statement (stmt) Objektes auf Basis der Verbindung
			stmt = conn.createStatement();
			
			// Ausfuehren des SQL-Befehls
			stmt.execute(sql);
			
			// liefert ResultSet zurueck, dass die geforderten Daten enthaelt
			rs = stmt.getResultSet();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public int update (String sql) {
		try {
			// Erstellen des statement (stmt) Objektes auf Basis der Verbindung
			stmt = conn.createStatement();
						
			// Ausfuehren des SQL-Befehls
			// Die Anzahl der betroffenen Eintraege wird in anz gespeichert
			int anz = stmt.executeUpdate(sql);
			return anz;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		} 
	}
	
	public int adressenPrep(String plz, String ort) {
		try {
			PreparedStatement prep = conn.prepareStatement("INSERT INTO plz (plz,ort)" +
					"values (?,?)");
			
			prep.setString(1, plz);
			prep.setString(2, ort);
			
			int anz = prep.executeUpdate();
			return anz;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
}
