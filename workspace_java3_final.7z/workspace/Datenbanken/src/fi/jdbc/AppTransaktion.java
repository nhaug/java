package fi.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;


public class AppTransaktion {
	public static void main(String[] args) {
		DBZugriff dbz = new DBZugriff();
		dbz.connectionAufbauen();
		
		Connection conn = dbz.getConn();
		
		try {
			// true : alle executes werden automatisch commited ( in DB gespeichert)
			// false : commit muss manuell get�tigt werden, um die Daten in DB zu speichern.
			conn.setAutoCommit(false);
			
			String sql = "INSERT INTO plz VALUES ('9900','k�ln')";
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			
			sql = "INSERT INTO plz VALUES (9910','bei K�ln')";
			stmt.executeUpdate(sql);
			
			System.out.println("commit jetzt durchf�hren");
			conn.commit();
		} catch (SQLException e) {
			try {
				System.out.println("Rollback wird durchgefuehrt");
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	
	
}
