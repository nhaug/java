package fi.jdbc;

public class PLZ {
	// Variablen
	private String plz;
	private String ort;
	
	// Methoden
	public String getPlz() {
		return plz;
	}
	public void setPlz(String plz) {
		this.plz = plz;
	}
	public String getOrt() {
		return ort;
	}
	public void setOrt(String ort) {
		this.ort = ort;
	}
}
