package fi.jdbc;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AppDatum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// Weg 1: String in ein Datum umwandeln
			Date d = new SimpleDateFormat("dd.MM.yyyy").parse("10.10.2016");
			System.out.println(d);
			
			// Weg 2: Datum in String umwandeln
			String s = new SimpleDateFormat("dd.MM.yyyy").format(d);
			System.out.println(s);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
