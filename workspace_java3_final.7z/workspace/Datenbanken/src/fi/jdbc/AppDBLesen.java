package fi.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AppDBLesen {
	public static void main(String[] args) {
		DBZugriff dbc = new DBZugriff();
		if (dbc.connectionAufbauen() == true) {
			System.out.println("Connection Ok");
		} else {
			System.out.println("Connection nicht ok");
		}
		
		// ArrayList, in der die Abgefragten PLZ-Daten gespeichert werden
		ArrayList<PLZ> ar = new ArrayList<PLZ>();
		
		// Lesen der Daten aus DB
		String sql;
		//sql = "select * from plz";
		sql = "SELECT * FROM k";
		ResultSet rs = dbc.lesen(sql);
		
		// Lesen der Eintraege
		try {
			while (rs.next()) {
				PLZ p = new PLZ();
				p.setOrt(rs.getString("ort"));
				p.setPlz(rs.getString("plz"));
				ar.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Auswertung:
		System.out.println("--- Auswertung ---");
		for (PLZ p : ar) {
			System.out.println(p.getPlz()+"\t"+p.getOrt());
		}
		
	}
}
