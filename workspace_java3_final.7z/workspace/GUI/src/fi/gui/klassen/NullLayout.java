package fi.gui.klassen;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class NullLayout extends JFrame {
	private JPanel jContentPane = null;
	private JComboBox<String> cbNamen = null;
	private JButton btEnde = null;
	private JTextArea txtArea = null;
	private JTable tbl = null;
	private JScrollPane jScrollPane;
	
	public NullLayout() {
		super();
		initialize();
	}
	
	private void initialize() {
		this.setSize(500,500);
		this.setTitle("Null Layout");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setContentPane(this.getJContentPane());
	}
	
	public JPanel getJContentPane() {
		jContentPane = new JPanel();
		jContentPane.setLayout(null);
		
		// Combobox
		cbNamen = new JComboBox<String>();
		cbNamen.setBounds(10, 10, 100, 20);
		cbNamen.addItem("Maier");
		cbNamen.addItem("Huber");
		cbNamen.addItem("Schmidt");
		
		jContentPane.add(cbNamen);
		
		btEnde = new JButton("Ende");
		btEnde.setBounds(130, 10, 100, 20);
		
		btEnde.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				// Die Applikation beenden
				System.exit(0);
			}
		});
		jContentPane.add(btEnde);
		
		// Aufbau der TextArea
		txtArea  = new JTextArea();
		txtArea.setBounds(10, 50, 200, 200);
		jContentPane.add(txtArea);
		
		
		
		// Tabelleninhalt aufbauen
		// Spaltenbezeichner festlegen
		Vector<String> vColumns = new Vector<String>();
		vColumns.add("KontoNummer");
		vColumns.add("Betrag");
		vColumns.add("Datum");
		
		// Nun die Zeilen festlegen
		// Dazu 2. dimensionaler Vector aufbauen
		Vector<Vector<String>> vInhalt = new Vector<Vector<String>>();
		
		// 2 Zeilen einfuegen
		int i = 1;
		while ( i <= 10) {
			Vector<String> zeile = new Vector<String>();
			zeile.add("" + i);
			zeile.add("1000");
			zeile.add("2016.10.13");
			vInhalt.add(zeile);
			i++;
		}
				
		// Nun dieses Array in ein TableModel verwandeln
		// Model fpr die Verawaltung der Ovberschrift und der Daten
		DefaultTableModel model = new DefaultTableModel(vInhalt, vColumns);
		
		// Aufbau einer Tabelle und Zuordnung des Modells
		tbl = new JTable(model);
		
		// Ein ScrollPanel bauen und in dieses die Tabelle einbauen
		// Automatisch die Ueberschriften hinzufuegen
		jScrollPane = new JScrollPane(tbl);
		jScrollPane.setBounds(10, 300, 300, 100);
		jContentPane.add(jScrollPane);
		
		return jContentPane;
	}
}
