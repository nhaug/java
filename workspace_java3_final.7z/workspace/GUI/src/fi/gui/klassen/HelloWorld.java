package fi.gui.klassen;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.omg.CORBA.INITIALIZE;

public class HelloWorld extends JFrame {
	// panel = Bedienungsfeld
	private JPanel jContentPane = null;
	
	// Konstruktor
	public HelloWorld () {
		// Standardkonstrukte der Basisklasse auf
		super();
		
		// Methode die bei jeder Erstellung eines neuen Objekts aufgerufen werden soll
		initialize();
	}
	
	// Soll Grundwerte festlegen
	private void initialize() {
		this.setSize(500, 500);
		this.setTitle("Hello World");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setContentPane(getJContentPane());
	}
	
	private JPanel getJContentPane() {
		jContentPane = new JPanel();
		// Layouts: 
		//	Standard = FlowLayout
		//	meistverbreitete = BorderLayout
		
		jContentPane.setLayout(new BorderLayout());
		jContentPane.setBackground(Color.darkGray);
		
		
		for ( int i = 0 ; i < 50 ; i++) {
			JLabel l = new JLabel();
			l.setForeground(Color.WHITE);
			l.setText("Hello World");
			l.setFont(Font.getFont("Bold"));
			jContentPane.add(l);
		}
		return jContentPane;
	}
}
