package fi.gui.klassen;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultListSelectionModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.omg.CORBA.INITIALIZE;

public class BorderLayoutEinfach extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// panel = Bedienungsfeld	
	private JPanel jContentPane = null;				// Panel fuer Sueden
	private JPanel jMitte = null;					// Panel fuer Mitte
	private JPanel jSueden = null;
	private JPanel jWesten = null;
	private JTextField txtNachName = null;			// TextFeld fuer die Eingabe von Nachname
	private JTextField txtVorName = null;			// TextFeld fuer die eingabe von Vorname
	private JButton btEnde = null;					// Button einbauen, auf den geklickt werden kann und das Fenster schlie�t
	private Color defaultColorBG = Color.WHITE;		// Default Color f�r Background
	private JList<String> lbNamen = null;			// Listbox
	
	// Konstruktor
	public BorderLayoutEinfach () {
		// Standardkonstrukte der Basisklasse auf
		super();
		
		// Methode die bei jeder Erstellung eines neuen Objekts aufgerufen werden soll
		initialize();
	}
	
	// Soll Grundwerte festlegen
	private void initialize() {
		// Size width , high
		this.setSize(500, 200);				// Setze groesse des Frames mit pixel-Angaben
		this.setTitle("Hello World");		// Setze Titel auf Hello World
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	// Wenn bei dem Frame auf "Close" geklickt wird, wird der Java-Prozess beendet und vom Garbage Collector entfernt.
		this.setContentPane(getJContentPane());		// Aufbauen des Standard Panels
		this.setResizable(false);				// Benutzer kann das Fenster nicht skalieren. Dadurch sieht die Anwendung immer gut aus.
	}
	
	// Funktion, die Standard-Panel aufbaut
	private JPanel getJContentPane() {
		jContentPane = new JPanel();
		
		// Layouts: 
		//	Standard = FlowLayout (	Wenn ich kein  Layout festlege, wird das FlowLayout genutzt )
		//	meistverbreitete = BorderLayout
		jContentPane.setLayout(new BorderLayout());
		
		// Im BorderLayout die einzelnen Seiten als Button macht
		jContentPane.add(new JButton("Norden"),BorderLayout.NORTH);
		jContentPane.add(getJSueden(),BorderLayout.SOUTH);
		jContentPane.add(getJWesten(),BorderLayout.WEST);
		jContentPane.add(new JButton("Osten"),BorderLayout.EAST);
		jContentPane.add(getJMitte(),BorderLayout.CENTER);
		
		return jContentPane;
	}
	private JPanel getJWesten() {
		// Definition was im Westen geschehen soll
		// Hier soll eine Liste angezeigt werden
		jWesten = new JPanel();
		jWesten.setBackground(defaultColorBG);
		
		lbNamen = new JList<String>();

		Vector<String> tab = new Vector<String>();
		tab.add("Maier");
		tab.add("Huber");
		tab.add("M�ller");
		
		lbNamen.setListData(tab);
		lbNamen.setSelectionMode(DefaultListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		lbNamen.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				// TODO Auto-generated method stub
				// Messagebox anzeigen
				// 1: Owner = null, gleicher Owner wie die der Maske
				// 2: ausgewaehlter Eintrag aus ListBox
				//JOptionPane.showMessageDialog(null, lbName.getSelectedValue());
				//txtNachName.setText(lbNamen.getSelectedValue());
				//txtVorName.setText("");
				List<String> li = lbNamen.getSelectedValuesList();
				String selNamen = "";
				for (String name : li) {
					selNamen +=name+" ";
				}
				txtNachName.setText(selNamen);
			}
		});
		
		jWesten.add(lbNamen); 
		
		return jWesten;
	}
	
	
	private JPanel getJMitte() {

		jMitte = new JPanel();
		jMitte.setLayout(new GridLayout(2,2));
		
		FocusListener focusImpl = new FocusListenerImplement();
		
		jMitte.add(new JLabel("Nachname"));
		txtNachName = new JTextField();
		txtNachName.addFocusListener(focusImpl);
		jMitte.add(txtNachName);
		
		jMitte.add(new JLabel("Vorname"));
		txtVorName = new JTextField();
		txtVorName.addFocusListener(focusImpl);
		jMitte.add(txtVorName);
		
		return jMitte;
	}
	
	private JPanel getJSueden() {
		jSueden = new JPanel();
		jSueden.setBackground(Color.RED);
		btEnde = new JButton("ENDE");
		btEnde.setBounds(0, 0, 500, 50);
		
		// Bei Klick auf Button soll etwas geschehen
		// Weil wir mit einem Interface sprechen, m�ssen die hier initialsierten Methoden deklariert werden
		// Dies ist eine anonyme innere Klasse
		// Vorteil Innere Klasse: Sie kann auf die private Attribute der Umgebenden Klasse zugreifen
		btEnde.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				// Die Applikation beenden
				System.exit(0);
			}
		});
		
		
		jSueden.add(btEnde);
		
		return jSueden;
	}
	
	// Innere Klasse, innerhalb der umgebenen Klasse
	class FocusListenerImplement implements FocusListener {

		// Fokus = Darauf zu klicken
		@Override
		public void focusGained(FocusEvent arg0) {
			// Wenn Benutzer das Textfeld fokussiert hat
			JTextField t = (JTextField) arg0.getSource();
			t.setBackground(Color.LIGHT_GRAY);
		}

		@Override
		public void focusLost(FocusEvent arg0) {
			// TODO Auto-generated method stub
			JTextField t = (JTextField) arg0.getSource();
			t.setBackground(defaultColorBG);
		}
		
	}
	
}
