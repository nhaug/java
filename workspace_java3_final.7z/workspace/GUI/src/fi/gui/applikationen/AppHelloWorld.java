package fi.gui.applikationen;

import fi.gui.klassen.HelloWorld;

public class AppHelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HelloWorld h = new HelloWorld();
		h.setVisible(true);
	}

}
