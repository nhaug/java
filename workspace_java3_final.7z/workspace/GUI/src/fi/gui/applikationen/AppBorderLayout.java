package fi.gui.applikationen;

import fi.gui.klassen.BorderLayoutEinfach;

public class AppBorderLayout {
	public static void main(String[] args) {
		// Neuen Frame mit BorderLayout erstellen. Dazu soll unsere eigene Klasse genutzt werden
		BorderLayoutEinfach frame = new BorderLayoutEinfach();
		frame.setVisible(true);
	}
}
