package fi.gui.applikationen;
import java.awt.Component;

import javax.swing.JFrame;


public class AppBeginn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame();
		// Component button = new JFrame();
		//frame.add("hallo",button);
		frame.setSize(500,500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}

}
