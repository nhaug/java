package fi.gui.applikationen;

import fi.gui.klassen.NullLayout;

public class AppNullLayout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NullLayout frame = new NullLayout();
		frame.setVisible(true);
	}

}
